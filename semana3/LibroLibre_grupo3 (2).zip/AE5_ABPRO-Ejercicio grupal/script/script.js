document.addEventListener('DOMContentLoaded', () => {

    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const bookList = document.getElementById('book-list');
    const bookItems = document.querySelectorAll('.book-item');
    const bookCountDisplay = document.getElementById('book-count');
    const registrationForm = document.getElementById('registration-form');
    const registrationMessage = document.getElementById('registration-message');




    const performSearch = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        let foundBooksCount = 0; 

        bookItems.forEach(bookItem => {
            const title = bookItem.dataset.title.toLowerCase();
            const author = bookItem.dataset.author.toLowerCase();
            const genre = bookItem.dataset.genre.toLowerCase();


            if (title.includes(searchTerm) || author.includes(searchTerm) || genre.includes(searchTerm)) {
                bookItem.style.display = 'block'; 
                foundBooksCount++; 
            } else {
                bookItem.style.display = 'none';
            }
        });


        if (searchTerm === '') {
            bookCountDisplay.textContent = `Mostrando todos los ${bookItems.length} libros.`;
        } else if (foundBooksCount === 0) {
            bookCountDisplay.textContent = `No se encontraron libros para "${searchInput.value}".`;
        } else {

            bookCountDisplay.textContent = `Se encontraron ${foundBooksCount} libros para "${searchInput.value}".`;
        }
    };


    searchButton.addEventListener('click', performSearch);
    searchInput.addEventListener('keyup', (event) => {

        performSearch();

    });


    performSearch();



    registrationForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const nombre = document.getElementById('nombre').value.trim();
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();


        registrationMessage.textContent = '';
        registrationMessage.style.color = '';


        if (nombre === '' || email === '' || password === '') {
            registrationMessage.textContent = 'Por favor, completa todos los campos.';
            registrationMessage.style.color = 'red';
            console.error('Error de validación: Campos vacíos.');
            return;
        }


        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            registrationMessage.textContent = 'Por favor, ingresa un correo electrónico válido.';
            registrationMessage.style.color = 'red';
            console.error('Error de validación: Correo electrónico inválido.');
            return;
        }


        if (password.length < 6) {
            registrationMessage.textContent = 'La contraseña debe tener al menos 6 caracteres.';
            registrationMessage.style.color = 'red';
            console.error('Error de validación: Contraseña demasiado corta.');
            return;
        }


        registrationMessage.textContent = '¡Registro exitoso! Gracias por unirte a LibroLibre.';
        registrationMessage.style.color = 'green';
        console.log('Registro exitoso:', { nombre, email, password: '***' }); 

        registrationForm.reset();
    });


    console.log('Script.js cargado y DOM listo.');
    console.log('Número total de libros en el catálogo:', bookItems.length);

});